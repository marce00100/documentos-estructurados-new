biblioteca = [
    {type: "input", id: 1},
    {type: "textarea", id: 1, parametros: ["uno", "dos", "tres"]},
    {type: "op_multiple", id: 1}
]